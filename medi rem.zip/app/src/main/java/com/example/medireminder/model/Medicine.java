package com.example.medireminder.model;

import org.json.JSONException;
import org.json.JSONObject;

public class Medicine {

    public int id;
    public String name;
    public String time;

    public Medicine(int id, String name, String time){
        this.id = id;
        this.name = name;
        this.time = time;
    }

    public JSONObject toJSON(){
        JSONObject obj = new JSONObject();
        try {
            obj.put("id", id);
            obj.put("name", name);
            obj.put("time", time);
        } catch (JSONException e){
            e.printStackTrace();
        }
        return obj;
    }

    public static Medicine fromJSON(JSONObject obj){
        try {
            return new Medicine(obj.getInt("id"), obj.getString("name"), obj.getString("time"));
        } catch (JSONException e){
            e.printStackTrace();
            return null;
        }
    }
}
