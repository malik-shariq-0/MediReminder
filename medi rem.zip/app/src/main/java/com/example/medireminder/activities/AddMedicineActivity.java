package com.example.medireminder.activities;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.medireminder.R;
import com.example.medireminder.model.Medicine;

import org.json.JSONArray;

import java.util.Calendar;

import static android.Manifest.permission.POST_NOTIFICATIONS;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

public class AddMedicineActivity extends AppCompatActivity {

    EditText etMedicineName;
    TimePicker timePicker;
    Button btnSave;

    boolean isEdit = false;
    int editId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_medicine);

        // Notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, POST_NOTIFICATIONS) != PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{POST_NOTIFICATIONS}, 101);
            }
        }

        etMedicineName = findViewById(R.id.etMedicineName);
        timePicker = findViewById(R.id.timePicker);
        btnSave = findViewById(R.id.btnSave);

        isEdit = getIntent().getBooleanExtra("edit", false);
        editId = getIntent().getIntExtra("id", -1);

        if (isEdit) {
            etMedicineName.setText(getIntent().getStringExtra("name"));
            String time = getIntent().getStringExtra("time");
            if (time != null) {
                String[] parts = time.split(":");
                timePicker.setHour(Integer.parseInt(parts[0]));
                timePicker.setMinute(Integer.parseInt(parts[1]));
            }
        }

        btnSave.setOnClickListener(v -> saveMedicine());
    }

    private void saveMedicine() {
        String medicineName = etMedicineName.getText().toString().trim();
        if (medicineName.isEmpty()) {
            Toast.makeText(this, "Enter medicine name", Toast.LENGTH_SHORT).show();
            return;
        }

        int hour = timePicker.getHour();
        int minute = timePicker.getMinute();
        String time = String.format("%02d:%02d", hour, minute);

        int medicineId = isEdit ? editId : (int) System.currentTimeMillis();
        Medicine medicine = new Medicine(medicineId, medicineName, time);

        SharedPreferences prefs = getSharedPreferences("medireminder", MODE_PRIVATE);
        String jsonString = prefs.getString("medicines", null);

        JSONArray array = new JSONArray();
        try {
            if (jsonString != null) array = new JSONArray(jsonString);

            if (isEdit) {
                for (int i = 0; i < array.length(); i++) {
                    if (array.getJSONObject(i).getInt("id") == editId) {
                        array.remove(i);
                        break;
                    }
                }
            }

            array.put(medicine.toJSON());
            prefs.edit().putString("medicines", array.toString()).apply();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving medicine", Toast.LENGTH_SHORT).show();
            return;
        }

        // Set daily Alarm
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);
        if(calendar.getTimeInMillis() <= System.currentTimeMillis())
            calendar.add(Calendar.DAY_OF_MONTH,1);

        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("medicine", medicineName);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                medicineId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        if(alarmManager != null){
            alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    AlarmManager.INTERVAL_DAY,
                    pendingIntent
            );
        }

        Toast.makeText(this, isEdit ? "Medicine updated" : "Medicine added", Toast.LENGTH_SHORT).show();
        finish();
    }
}
